These scripts define the bussiness logic and UI of DiVE. Ideally they should be put in a class that can be built by grunt, together with the sripts from src_graphosaurus.
